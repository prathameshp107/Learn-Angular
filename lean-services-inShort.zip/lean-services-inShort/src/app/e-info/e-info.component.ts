import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-e-info',
  templateUrl: './e-info.component.html',
  styleUrls: ['./e-info.component.css'],
  providers:[DataService]
})
export class EInfoComponent implements OnInit {
  constructor(private dService:DataService) { }

  infoReceived1: string[]=[];
  infoReceived2: string[]=[];
  infoReceived3: string[]=[];

  getInfoFromService1(){
    this.infoReceived1=this.dService.getInfo1()
    console.log(this.infoReceived1);
  }
  getInfoFromService2(){
    this.infoReceived2=this.dService.getInfo2()
  }
  getInfoFromService3(){
    this.infoReceived3=this.dService.getInfo3()
  }

 

  ngOnInit(): void {
  }

}
