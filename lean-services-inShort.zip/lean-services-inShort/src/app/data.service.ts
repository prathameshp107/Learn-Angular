import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  info1: string[]=["Mathew wade",'E335','mw@abc.net']
  info2: string[]=["Glenn Maxwell",'E661','gm@abc.net']
  info3: string[]=["Kieron Pollard",'E246','kp@abc.net']
  
  getInfo1(){
    return this.info1
  }

  getInfo2(){
    return this.info2
  }

  getInfo3(){ 
    return this.info1
  }
  constructor() { }
}
